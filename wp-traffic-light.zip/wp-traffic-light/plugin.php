<?php
/**
 * Plugin Name:       Traffic Light
* Version:     1.0.1

*/

function include_bootstrap() {

    wp_enqueue_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js');
    wp_enqueue_script('js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js');
    wp_enqueue_style('google-font-roboto', 'https://fonts.googleapis.com/css?family=Roboto|Varela+Round');
    wp_enqueue_style('google-icon', 'https://fonts.googleapis.com/icon?family=Material+Icons');
    wp_enqueue_style('font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');
    // wp_enqueue_style('bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css');
    
    
    wp_enqueue_style( 'style', plugin_dir_url(__FILE__).'css/style.css' );
}  
add_action('wp_enqueue_scripts', 'include_bootstrap');


global $wptl_db_version;
$wptl_db_version = '1.0.1';


function tl_create_db() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
   
    //* Create the teams table
    $table_name = $wpdb->prefix . 'tl_rpa';
    $sql = "CREATE TABLE $table_name (
    id INT NOT NULL AUTO_INCREMENT,
    user_nt VARCHAR(50) NOT NULL,
    filepath VARCHAR(250) NOT NULL,
    `filename` VARCHAR(250) NOT NULL,
    triggertime VARCHAR(50) NOT NULL,
    PRIMARY KEY (id)
    ) $charset_collate;";
    dbDelta( $sql );
   }

register_activation_hook( __FILE__, 'tl_create_db' );
/*
function wptl_install()
{
    global $table_prefix, $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $tablename = $wpdb->prefix . 'tl-rpa';
    require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
    #Check to see if the table exists already, if not, then create it

    if($wpdb->get_var( "show tables like '$tablename'" ) != $tablename) 
    {
        $sql = "CREATE TABLE $table_name (
            id INT NOT NULL AUTO_INCREMENT,
            user_nt VARCHAR(50) NOT NULL,
            filepath VARCHAR(250) NOT NULL,
            filename VARCHAR(250) NOT NULL,
            triggertime VARCHAR(50) NOT NULL,
            PRIMARY KEY (id)
            ) $charset_collate;";
        
        dbDelta($sql);
    }
    add_option('wptl_db_version', $wptl_db_version);
}
register_activation_hook( __FILE__, 'wptl_install' );
function wptl_update_db_check()
{
    global $wptl_db_version;
    if (get_site_option('wptl_db_version') != $wptl_db_version) {
        wptl_install();
    }
}

add_action('plugins_loaded', 'wptl_update_db_check');
*/
function traffic_light_thead_html() {
    $content = '';
    $content .= '<head>';
    $content .= '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">';
    $content .= '</head>';
    $content .= '<body>';
    $content .= '<br>';
    $content .= '<br>';
    $content .= '<h3 class="text-center text-success" id="message"><?php echo  $success; ?></h3>';
    $content .= '<div class="container">';
    $content .= '<div class="table-wrapper">';
    $content .= '<div class="table-title">';
    $content .= '<div class="row">';
    $content .= '<div class="col-sm-6">';
    $content .= '<h2><b>紅綠燈註冊</b></h2>';
    $content .= '</div>';
    $content .= '<div class="col-sm-6">';
    $content .= '<a href="#addEmployeeModal" class="btn btn-success" data-toggle="modal"><i class="material-icons">&#xE147;</i> <span>Add New Employee</span></a>';
    // $content .= '<a href="#deleteEmployeeModal" class="btn btn-danger" data-toggle="modal"><i class="material-icons">&#xE15C;</i> <span>Delete</span></a>   ';
    $content .= '</div>';
    $content .= '</div>';
    $content .= '</div>';
    $content .= '<table class="table table-striped table-hover">';
    $content .= '<thead>';
    $content .= '<tr>';
    $content .= '<th>File Path</th>';
    $content .= '<th>File Name</th>';
    $content .= '<th>Trigger Time</th>';
    $content .= '<th>Actions</th>';
    $content .= '</tr>';
    $content .= '<thead>';
    return $content;
}
function traffic_light_record_html() {
    global $wpdb;
    $userid = get_current_user_id();
    $table_name = $wpdb->prefix . 'tl_rpa';
    $result = $wpdb->get_results ("SELECT * FROM  $table_name WHERE user_nt = $userid" );

    $content = '';
    $content .= '<tbody>';
    foreach ( $result as $key => $record) {
        $content .= '<tr>';
        $content .= '<td id="filepath_'.$record->id.'">'.$record->filepath.'</td>';
        $content .= '<td id="filename_'.$record->id.'">'.$record->filename.'</td>';
        $content .= '<td id="triggertime_'.$record->id.'">'.$record->triggertime.'</td>';
        $content .= '<td>';
        $content .= '<a href="#editEmployeeModal" class="edit" data-id="'.$record->id.'" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></a>';
        $content .= '<a href="#deleteEmployeeModal" class="delete" data-id="'.$record->id.'" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>';
        $content .= '</tr>';
    }
    $content .= '</tbody>';
    $content .= '</table>';
    $content .= '</div>';
    $content .= '</div>';
    return $content;
}

function traffic_light_add_modal() {
    $content = '';
    $content .= '<div id="addEmployeeModal" class="modal fade">';
    $content .= '<div class="modal-dialog">';
    $content .= '<div class="modal-content">';
    $content .= '<form method="post">';
    $content .= '<div class="modal-header">';
    $content .= '<h4 class="modal-title">Add Record</h4>';
    $content .= '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>';
    $content .= '</div>';
    $content .= '<div class="modal-body">';
    $content .= '<div class="form-group">';
    $content .= '<label>File Path</label>';
    $content .= '<input type="text" class="form-control" name="filepath" placeholder="Enter filepath" required>';
    $content .= '</div>';
    $content .= '<div class="form-group">';
    $content .= '<label>File Name</label>';
    $content .= '<input type="text" class="form-control" name="filename" placeholder="Enter filename" required>';
    $content .= '</div>';
    $content .= '<div class="form-group">';
    $content .= '<label>Trigger Time</label>';
    $content .= '<input type="time" class="form-control" name="triggertime" required>';
    $content .= '</div>';
    $content .= '</div>';
    $content .= '<div class="modal-footer">';
    $content .= '<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">';
    $content .= '<input type="submit" class="btn btn-success" name="add" value="Add">';
    $content .= '</div>';
    $content .= '</form>';
    $content .= '</div>';
    $content .= '</div>';
    $content .= '</div>';
    return $content;
  
}
function traffic_light_delete_modal() {
    $content = '';
    $content .= '<div id="deleteEmployeeModal" class="modal fade">';
    $content .= '<div class="modal-dialog">';
    $content .= '<div class="modal-content">';
    $content .= '<form method="post">';
    $content .= '<div class="modal-header">  ';
    $content .= '<h4 class="modal-title">Delete Record</h4>';
    $content .= '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>s';
    $content .= '</div>';
    $content .= '<div class="modal-body">';    
    $content .= '<p>Are you sure you want to delete these Records?</p>';
    $content .= '<p class="text-warning"><small>This action cannot be undone.</small></p>';
    $content .= '</div>';
    $content .= '<div class="modal-footer">';
    $content .= '<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">';
    $content .= '<input type="hidden" name="delete_id" id="delete_id" value="">';
    $content .= '<input type="submit" class="btn btn-danger" name="delete" value="Delete">';
    $content .= '</div>';
    $content .= '</form>';
    $content .= '</div>';
    $content .= '</div>';
    $content .= '</div>';

    return $content;
}
function traffic_light_edit_modal(){
    $content = '';
    $content .= '<div id="editEmployeeModal" class="modal fade">';
    $content .= '<div class="modal-dialog">';
    $content .= '<div class="modal-content">';
    $content .= '<form method="post">';
    $content .= '<div class="modal-header">';
    $content .= '<h4 class="modal-title">Add Record</h4>';
    $content .= '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>';
    $content .= '</div>';
    $content .= '<div class="modal-body">';
    $content .= '<div class="form-group">';
    $content .= '<label>File Path</label>';
    $content .= '<input type="text" class="form-control" name="edit_filepath" id="edit_filepath" value="" required>';
    $content .= '</div>';
    $content .= '<div class="form-group">';
    $content .= '<label>File Name</label>';
    $content .= '<input type="text" class="form-control" name="edit_filename" id="edit_filename" value="" required>';
    $content .= '</div>';
    $content .= '<div class="form-group">';
    $content .= '<label>Trigger Time</label>';
    $content .= '<input type="time" class="form-control" name="edit_timetrigger" id="edit_triggertime" defaultValue="" required>';
    $content .= '</div>';
    $content .= '</div>';
    $content .= '<div class="modal-footer">';
    $content .= '<input type="hidden" name="edit_id" id="edit_id" value="">';
    $content .= '<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">';
    $content .= '<input type="submit" class="btn btn-success" name="edit" value="Save">';
    $content .= '</div>';
    $content .= '</form>';
    $content .= '</div>';
    $content .= '</div>';
    $content .= '</div>';
    $content .= '</body>';
   
    return $content;
}
function js() {
    $content = '';
    $content .= "
    <script>
    jQuery('.delete').click(function($){
        var record_id = jQuery(this).data('id');
        document.getElementById('delete_id').value = record_id;
    });
    jQuery('.edit').click(function($){
        var record_id = jQuery(this).data('id');
        var filepath = 'filepath_'.concat(record_id);
        var filename = 'filename_'.concat(record_id);
        var triggertime = 'triggertime_'.concat(record_id);
        document.getElementById('edit_filepath').value = document.getElementById(filepath).textContent;
        document.getElementById('edit_filename').value = document.getElementById(filename).textContent;
        document.getElementById('edit_triggertime').defaultValue  = document.getElementById(triggertime).textContent;
        document.getElementById('edit_id').value = record_id;
    });
    </script>
    ";
    return $content;
}
function display_traffic_light_form() {
    $content = '';
    $content .= traffic_light_thead_html();
    $content .= traffic_light_record_html();
    $content .= traffic_light_add_modal();
    $content .= traffic_light_delete_modal();
    $content .= traffic_light_edit_modal();
    $content .= js();
    return $content;
}
add_shortcode( 'test', 'display_traffic_light_form' ); 

function process_login() {
    if ( is_page('tl-register') && ! is_user_logged_in() ) {
        auth_redirect();
    }
}
add_action('template_redirect', 'process_login');
function process_form () {
    global $wpdb;
    $table_name = $wpdb->prefix . 'tl_rpa';
    if( isset( $_POST['add'] ) ){
        $userid = get_current_user_id();
        $filepath = $_POST['filepath'];
        $filename = $_POST['filename'];
        $triggertime = $_POST['triggertime'];
        
        $wpdb->insert($table_name, array(
        "user_nt" => $userid,
        "filepath" => $filepath,
        "filename" => $filename,
        "triggertime" => $triggertime
        ));
    }

    if( isset( $_POST['delete'] ) ){
        $record_id = $_POST['delete_id'];
        $wpdb->delete( $table_name, array( 'id' => $record_id ) );
    }
    if( isset( $_POST['edit'] ) ){
        var_dump($_POST);
        $record_id = $_POST['edit_id'];
        $filepath = $_POST['edit_filepath'];
        $filename = $_POST['edit_filename'];
        $triggertime = $_POST['edit_timetrigger'];
        $wpdb->update($table_name, array('filepath'=>$filepath, 'filename'=>$filename, 'triggertime'=>$triggertime), array('id'=>$record_id));
    }    
}
add_action( 'wp_loaded', 'process_form' );